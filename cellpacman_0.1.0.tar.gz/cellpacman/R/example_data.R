#' Paths to the bundled example Cell Painting tables
#'
#' `cellpacman` ships fully synthetic tutorial data in `inst/extdata`:
#' 2,000 wells across eight plates, with 600 numeric features
#' (`example_features_mock.tsv`) and 20 metadata columns
#' (`example_metadata_mock.tsv`). Each plate contains 250 occupied positions
#' on a 384-position grid: three fictitious references (`RefA`, `RefB`, `RefC`)
#' at eight concentrations in duplicate, 16 synthetic `DMSO` controls,
#' and 186 unknown wells whose `Compound` is `NA`.
#'
#' All measurements, experiment identifiers and response patterns are synthetic.
#' Concentrations are in arbitrary tutorial units. These data demonstrate
#' software use and do not represent real compounds or biological findings.
#' The companion Shiny application loads these same tables by default.
#'
#' @param table Which table to locate: `"features"` or `"metadata"`.
#'
#' @return A single file path to a tab-separated table that can be passed to
#'   [loadCellPainting()].
#' @examples
#' exampleDataPath("features")
#' exampleDataPath("metadata")
#' @export
exampleDataPath <- function(table = c("features", "metadata")) {
  table <- match.arg(table)
  example_data_path(switch(
    table,
    features = "example_features_mock.tsv",
    metadata = "example_metadata_mock.tsv"
  ))
}

# Resolve a file name inside the installed `extdata` directory. `system.file()`
# also resolves correctly under `devtools::load_all()`.
example_data_path <- function(file) {
  path <- system.file("extdata", file, package = "cellpacman", mustWork = FALSE)
  if (!nzchar(path)) {
    stop("Example data file `", file, "` was not found in the installed package.")
  }
  path
}
