## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>", eval = FALSE)

## ----run----------------------------------------------------------------------
#  install.packages("cellpacman_0.1.0_mock.tar.gz", repos = NULL, type = "source")
#  
#  # Use this local copy to keep the mock-data package and app in sync:
#  shiny::runApp("/path/to/cellpacman/cellpacman-shiny")

## ----run-example--------------------------------------------------------------
#  Sys.setenv(CELLPACMAN_EXAMPLE_DATA = "true", CELLPACMAN_WORKERS = "2")
#  shiny::runApp("cellpacman-shiny")

## ----data-tab, eval = TRUE, echo = FALSE, out.width = "100%"------------------
knitr::include_graphics("../man/figures/app-data.png")

## ----dimred-tab, eval = TRUE, echo = FALSE, out.width = "100%"----------------
knitr::include_graphics("../man/figures/app-dimension-reduction.png")

## ----clustering-tab, eval = TRUE, echo = FALSE, out.width = "100%"------------
knitr::include_graphics("../man/figures/app-clustering.png")

## ----trajectory-tab, eval = TRUE, echo = FALSE, out.width = "100%"------------
knitr::include_graphics("../man/figures/app-trajectory.png")

## ----tests--------------------------------------------------------------------
#  testthat::test_dir("cellpacman-shiny/tests/testthat")

