## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE, comment = "#>",
  message = FALSE, warning = FALSE,
  fig.width = 7, fig.height = 4.5, out.width = "100%",
  eval = TRUE
)

## ----libraries----------------------------------------------------------------
library(cellpacman)
library(dplyr)
library(tidyr)
library(ggplot2)

## ----load---------------------------------------------------------------------
dat <- loadCellPainting(
  file.feature  = exampleDataPath("features"),
  file.metadata = exampleDataPath("metadata")
)

dim(dat$feature_data)
dat$metadata |>
  mutate(Compound = ifelse(is.na(Compound), "(unknown)", Compound)) |>
  group_by(Compound) |>
  summarise(
    wells = n(),
    plates = n_distinct(Plate),
    concentrations = n_distinct(Concentration, na.rm = TRUE),
    .groups = "drop"
  ) |>
  knitr::kable()

## ----split, eval = FALSE------------------------------------------------------
#  raw <- readCellPainting("PlateResults.tsv")
#  
#  feature_tbl  <- raw |> select(WellId, contains("NonBorder Cells"))
#  metadata_tbl <- raw |> select(!contains("NonBorder Cells"))
#  
#  dat <- loadCellPainting(feature_tbl, metadata_tbl)

## ----normalize----------------------------------------------------------------
dat_norm <- normalize(dat, method = "z.score", by = "Plate")

## ----dimreduce----------------------------------------------------------------
dat_dr <- dimReduce(dat_norm, method = "umap", random_seed = 1)
head(dat_dr$reduced_data[, c("WellId", "Plate", "Compound", "Concentration", "x", "y")])

## ----plot-dimred, fig.height = 5----------------------------------------------
plotDimred(dat_dr)

## ----plot-plate, fig.height = 5-----------------------------------------------
ggplot(dat_dr$reduced_data, aes(x, y, colour = Plate)) +
  geom_point(size = 0.6, alpha = 0.7) +
  labs(x = "DIM1", y = "DIM2", title = "UMAP embedding coloured by plate") +
  theme_bw()

## ----cluster------------------------------------------------------------------
clusters <- compoundCluster(dat_dr, method = "dbscan", eps = 0.5, minPts = 5)

sapply(clusters$known_clusters, nrow)   # clusters per known compound
clusters$unknown_centroids              # unknown clusters

## ----plot-unknown-clusters, fig.height = 5------------------------------------
plotUnknownClusters(clusters)

## ----plot-known-clusters, fig.height = 5--------------------------------------
plotKnownClusters(clusters, compound = "Cabo")

## ----curves-------------------------------------------------------------------
curves <- curveEstimate(dat_dr, method = "princurve", eps = 0.5, minPts = 5, smoother = "lowess")

names(curves$curves)
curves$curves[["Cabo"]]$ref_points

## ----plot-known-curve, fig.width = 8, fig.height = 3.5------------------------
focus_compound <- "Cabo"
plotKnownCurves(curves, compound = focus_compound)

## ----project------------------------------------------------------------------
proj <- curveProject(curves)

proj$best_matches |>
  transmute(
    `Unknown cluster` = unknown_cluster,
    `Best-match compound` = compound,
    `Estimated concentration` = signif(estimated_concentration, 3),
    `Distance to curve` = round(distance, 2)
  ) |>
  arrange(`Unknown cluster`) |>
  knitr::kable()

## ----plot-projection, fig.width = 9, fig.height = 7---------------------------
plotUnknownProjections(curves, proj, compound = focus_compound)

## ----feature-curve, fig.width = 9, fig.height = 4-----------------------------
feat_curve <- selectFeatureCurve(curves, data.norm = dat_norm, p.adjust = "bonferroni", cutoff = 0.05)

feat_curve[[focus_compound]]$top_10 |>
  mutate(feature = sub("^NonBorder Cells - (CP_ )?", "", feature)) |>
  select(feature, median_difference, adjusted_p_value, significance) |>
  knitr::kable(digits = 3)

feat_curve[[focus_compound]]$heatmap_data |>
  pivot_longer(-c(bin, mean_concentration), names_to = "feature", values_to = "value") |>
  mutate(feature = sub("^NonBorder Cells - (CP_ )?", "", feature)) |>
  ggplot(aes(factor(bin), feature, fill = value)) +
  geom_tile() +
  scale_fill_gradient2(low = "#2166ac", mid = "white", high = "#b2182b") +
  labs(
    x = "Trajectory bin (low to high concentration)", y = NULL, fill = "Mean z",
    title = paste("Top features along the", focus_compound, "trajectory")
  ) +
  theme_minimal(base_size = 9)

## ----feature-cluster, fig.width = 9, fig.height = 4.5-------------------------
feat_cluster <- selectFeatureCluster(clusters, data.norm = dat_norm)

ggplot(feat_cluster, aes(median_difference, -log10(adjusted_p_value), colour = significance)) +
  geom_point(size = 0.8, alpha = 0.7) +
  geom_hline(yintercept = -log10(0.05), linetype = "dashed") +
  geom_vline(xintercept = c(-0.5, 0.5), linetype = "dashed") +
  facet_wrap(~ comparison) +
  labs(x = "Median difference (second vs first cluster)", y = expression(-log[10]~"adjusted p")) +
  theme_minimal()

## ----compare------------------------------------------------------------------
compareCompoundFeatures(dat_norm, first = "DMSO", second = "Cabo") |>
  head(5) |>
  mutate(feature = sub("^NonBorder Cells - (CP_ )?", "", feature)) |>
  knitr::kable(digits = 3)

## ----session------------------------------------------------------------------
sessionInfo()

